
// tools/ledger-verify-badge.js
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const LEDGER_PATH = path.resolve("./fact-ledger.jsonl");
const README_PATH = path.resolve("./README.md");

function canon(core) {
  const keys = Object.keys(core).sort();
  const o = {};
  for (const k of keys) o[k] = core[k];
  return JSON.stringify(o);
}
function sha256(s){ return crypto.createHash("sha256").update(s).digest("hex"); }

function verifyLedger() {
  if (!fs.existsSync(LEDGER_PATH)) return { ok: false, reason: "missing ledger" };
  const lines = fs.readFileSync(LEDGER_PATH, "utf8").trim().split("\n").filter(Boolean);
  let prev = "genesis";
  for (let i = 0; i < lines.length; i++) {
    const e = JSON.parse(lines[i]);
    if (e.prev !== prev) return { ok: false, reason: `prev link mismatch at ${i}` };
    const calc = sha256(canon({
      index: e.index, timestamp: e.timestamp, branch: e.branch, commit: e.commit, metrics: e.metrics, prev: e.prev
    }));
    if (calc !== e.hash) return { ok: false, reason: `hash mismatch at ${i}` };
    prev = e.hash;
  }
  return { ok: true, reason: "verified" };
}

function updateBadge(ok) {
  const badge = ok
    ? "![Highmark Verified](https://img.shields.io/badge/highmark-verified-brightgreen?style=flat-square)"
    : "![Highmark Broken](https://img.shields.io/badge/highmark-broken-red?style=flat-square)";
  const md = fs.readFileSync(README_PATH, "utf8");
  const updated = md.replace(/!\[Highmark.*?\)\]/, badge);
  fs.writeFileSync(README_PATH, updated);
  console.log(ok ? "✅ Ledger verified" : "❌ Ledger invalid");
  process.exit(ok ? 0 : 1);
}

const res = verifyLedger();
updateBadge(res.ok);
