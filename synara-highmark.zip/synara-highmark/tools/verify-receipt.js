
// tools/verify-receipt.js
"use strict";

const fs = require("fs");
const crypto = require("crypto");

const path = "./tests/perf-summary.json";

if (!fs.existsSync(path)) {
  console.error("No perf-summary.json found");
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(path, "utf8"));
const { receipt, timestamp, compTime, decTime, ratio, threshold } = data;

const serialized = JSON.stringify({ compTime, decTime, ratio, threshold, timestamp });
const rehash = crypto.createHash("sha256").update(serialized).digest("hex");

if (rehash === receipt) {
  console.log("✅ Verified Fact Receipt");
  process.exit(0);
} else {
  console.error("❌ Receipt mismatch");
  process.exit(2);
}
