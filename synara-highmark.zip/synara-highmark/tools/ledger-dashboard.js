
// tools/ledger-dashboard.js
"use strict";

const fs = require("fs");
const path = require("path");

const LEDGER_PATH = path.resolve("./fact-ledger.jsonl");
const HIGHMARK_PATH = path.resolve("./highmark.json");
const OUTPUT = path.resolve("./public/metrics.html");

function loadLedger(){
  if (!fs.existsSync(LEDGER_PATH)) return [];
  return fs.readFileSync(LEDGER_PATH, "utf8").trim().split("\n").filter(Boolean).map(l => JSON.parse(l));
}

function loadHighmark(){
  if (!fs.existsSync(HIGHMARK_PATH)) return null;
  return JSON.parse(fs.readFileSync(HIGHMARK_PATH,"utf8"));
}

function generate(ledger, highmark){
  const json = JSON.stringify(ledger);
  const hm = JSON.stringify(highmark);
  return `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Synara Highmark Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/react@18/umd/react.production.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/react-dom@18/umd/react-dom.production.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/recharts@2.10.0/umd/Recharts.min.js"></script>
<style>
body{margin:0;background:#0e1013;color:#e4e4e4;font-family:system-ui,sans-serif}
h1{text-align:center;margin:1rem 0;color:#00e676}
.wrap{width:92%;margin:0 auto;max-width:1200px}
.card{background:#171a1f;border-radius:12px;padding:14px;margin:16px 0;box-shadow:0 0 12px #0a0a0a}
small{color:#bbb}
</style>
</head>
<body>
<h1>📊 Synara Highmark Dashboard</h1>
<div class="wrap">
  <div id="root"></div>
  <div class="card"><small>Generated ${new Date().toISOString()}</small></div>
</div>
<script>
const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } = Recharts;
const ledger = ${json};
const highmark = ${hm};

function App(){
  const data = ledger.map((e, i) => ({
    idx: i+1,
    ratio: e.metrics.ratio,
    comp: e.metrics.compTime,
    dec: e.metrics.decTime,
    ts: e.timestamp
  }));
  const hmIndex = highmark ? ledger.findIndex(e => e.hash === highmark.hash) + 1 : null;
  return React.createElement(React.Fragment, null,
    React.createElement('div', {className:'card'},
      React.createElement('h3', null, 'Compression Ratio'),
      React.createElement(ResponsiveContainer, {width:'100%', height:320},
        React.createElement(LineChart, {data},
          React.createElement(CartesianGrid, { stroke:'#333'}),
          React.createElement(XAxis, { dataKey:'idx', stroke:'#aaa'}),
          React.createElement(YAxis, { stroke:'#aaa'}),
          React.createElement(Tooltip, null),
          React.createElement(Legend, null),
          highmark ? React.createElement(ReferenceLine, {x: hmIndex, stroke:'#ff4081', label:'Highmark', strokeDasharray:'5 5'}) : null,
          React.createElement(Line, {type:'monotone', dataKey:'ratio', stroke:'#00e676', dot:true})
        )
      )
    ),
    React.createElement('div', {className:'card'},
      React.createElement('h3', null, 'Compression / Decompression (ms)'),
      React.createElement(ResponsiveContainer, {width:'100%', height:320},
        React.createElement(LineChart, {data},
          React.createElement(CartesianGrid, { stroke:'#333'}),
          React.createElement(XAxis, { dataKey:'idx', stroke:'#aaa'}),
          React.createElement(YAxis, { stroke:'#aaa'}),
          React.createElement(Tooltip, null),
          React.createElement(Legend, null),
          highmark ? React.createElement(ReferenceLine, {x: hmIndex, stroke:'#ff4081', label:'Highmark', strokeDasharray:'5 5'}) : null,
          React.createElement(Line, {type:'monotone', dataKey:'comp', stroke:'#29b6f6', dot:false}),
          React.createElement(Line, {type:'monotone', dataKey:'dec', stroke:'#fbc02d', dot:false})
        )
      )
    )
  );
}
ReactDOM.render(React.createElement(App), document.getElementById('root'));
</script>
</body>
</html>`;
}

function main(){
  const ledger = loadLedger();
  const highmark = loadHighmark();
  if (!fs.existsSync(path.dirname(OUTPUT))) fs.mkdirSync(path.dirname(OUTPUT), {recursive:true});
  fs.writeFileSync(OUTPUT, generate(ledger, highmark));
  console.log("✅ Dashboard generated:", OUTPUT);
}

if (require.main === module) main();
