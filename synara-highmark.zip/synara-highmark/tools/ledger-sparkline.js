
// tools/ledger-sparkline.js
"use strict";

const fs = require("fs");
const { resolve } = require("path");

const LEDGER_PATH = resolve("./fact-ledger.jsonl");

function makeSparkline(values) {
  if (!values.length) return "";
  const blocks = "▁▂▃▄▅▆▇█";
  const min = Math.min(...values);
  const max = Math.max(...values);
  return values.map(v => {
    if (max === min) return blocks[blocks.length - 1];
    const idx = Math.floor(((v - min) / (max - min)) * (blocks.length - 1));
    return blocks[idx];
  }).join("");
}

function build() {
  if (!fs.existsSync(LEDGER_PATH)) return { ratio: "", comp: "", dec: "" };
  const lines = fs.readFileSync(LEDGER_PATH, "utf8").trim().split("\n").filter(Boolean);
  const recent = lines.slice(-10).map(l => JSON.parse(l));
  const ratio = makeSparkline(recent.map(e => e.metrics.ratio));
  const comp = makeSparkline(recent.map(e => e.metrics.compTime));
  const dec = makeSparkline(recent.map(e => e.metrics.decTime));
  console.log("Compression ratio trend:", ratio);
  console.log("Compression time trend:", comp);
  console.log("Decompression time trend:", dec);
}

if (require.main === module) build();

module.exports = { makeSparkline };
