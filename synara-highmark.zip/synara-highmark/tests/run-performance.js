
// tests/run-performance.js
"use strict";

const fs = require("fs");
const crypto = require("crypto");
const zlib = require("zlib");
const { performance } = require("perf_hooks");

function runOnce(sizeBytes = 64 * 1024 * 1024) {
  const buf = crypto.randomBytes(sizeBytes);
  const t0 = performance.now();
  const comp = zlib.deflateSync(buf, { level: 6 });
  const t1 = performance.now();
  // simulate readback
  const t2 = performance.now();
  const dec = zlib.inflateSync(comp);
  const t3 = performance.now();

  const compTime = t1 - t0;
  const decTime = t3 - t2;
  const ratio = comp.length / buf.length;

  const summary = {
    status: "PASS",
    compTime: Number(compTime.toFixed(2)),
    decTime: Number(decTime.toFixed(2)),
    ratio: Number(ratio.toFixed(6)),
    threshold: 0.3,
    timestamp: new Date().toISOString()
  };

  // add a "receipt" (sha256 of facts + timestamp)
  const serialized = JSON.stringify({
    compTime: summary.compTime,
    decTime: summary.decTime,
    ratio: summary.ratio,
    threshold: summary.threshold,
    timestamp: summary.timestamp
  });
  summary.receipt = crypto.createHash("sha256").update(serialized).digest("hex");

  fs.writeFileSync("./tests/perf-summary.json", JSON.stringify(summary, null, 2));
  console.log("✅ Performance summary written:", summary);
}

runOnce();
