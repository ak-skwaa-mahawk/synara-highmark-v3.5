# Synara Highmark v3.5 – Atlas Relay Network

(Full README as staged earlier.)