#!/usr/bin/env node
// tools/highmark-comment.js
import fs from "fs";

const data = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));

function spark(values){
  const bars = "▁▂▃▄▅▆▇█";
  const min = Math.min(...values), max = Math.max(...values);
  if (max === min) return bars[0].repeat(values.length);
  return values.map(v => bars[Math.floor(((v - min)/(max - min))*(bars.length-1))]).join("");
}

const ratioDiff = ((data.current.ratio - data.main.ratio) / data.main.ratio * 100);
const compDiff = ((data.current.compTime - data.main.compTime) / data.main.compTime * 100);
const trend = ratioDiff > 0 ? "📈 Improved" : "📉 Regression";
const color = ratioDiff > 0 ? "🟢" : "🔴";
const tag = ratioDiff > 5 ? "**🏁 Highmark Candidate!**" : "Within baseline range";

const md = `# ${color} ScottPOTbot Performance Analysis
**@johnbcarrolljr** your feature branch performance report is ready.

**Branch:** \`${data.branch}\`
**Main Baseline:** ${data.main.ratio.toFixed(3)} @ ${data.main.compTime}ms  
**Current:** ${data.current.ratio.toFixed(3)} @ ${data.current.compTime}ms  
**Delta:** ${trend}  
- Ratio: ${ratioDiff.toFixed(2)}%  
- Time: ${compDiff.toFixed(2)}%

**Trend:** \`${spark(data.recentRatios)}\`

> ${tag}
`;

fs.writeFileSync("pr-comment.md", md);
console.log(md);
