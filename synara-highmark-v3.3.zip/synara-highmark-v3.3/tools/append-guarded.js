
// tools/append-guarded.js
import { verifyFile } from "./sentinel-verify.js";
import { relayTest } from "./relay-run.js";
import { orionAlign } from "./orion-align.js";
import { append as ledgerAppend } from "./fact-ledger.js";
import fs from "fs";

(async function main(){
  verifyFile("tools/highmark.js");
  verifyFile("tools/fact-ledger.js");

  relayTest("node tests/run-performance.js");

  if (fs.existsSync("highmark.json") && fs.existsSync("tests/perf-summary.json")){
    const perf = JSON.parse(fs.readFileSync("tests/perf-summary.json", "utf8"));
    const hm = JSON.parse(fs.readFileSync("highmark.json", "utf8"));
    if (!orionAlign({ ratio: perf.ratio }, { metrics: hm.metrics })) {
      console.error("❌ Orion alignment failed — abort append.");
      process.exit(2);
    }
  }

  ledgerAppend();
  console.log("✅ Guarded append complete.");
})().catch(e => { console.error(e); process.exit(1); });
