
// tools/highmark.js
import fs from "fs";
import path from "path";
import crypto from "crypto";

const LEDGER_PATH = path.resolve("./fact-ledger.jsonl");
const HIGHMARK_PATH = path.resolve("./highmark.json");

function loadLedger(){
  if (!fs.existsSync(LEDGER_PATH)) return [];
  return fs.readFileSync(LEDGER_PATH, "utf8").trim().split("\n").filter(Boolean).map(l => JSON.parse(l));
}

function create(){
  const ledger = loadLedger();
  if (ledger.length === 0) { console.error("❌ No ledger entries."); process.exit(1); }
  const last = ledger.at(-1);
  const highmark = {
    timestamp: new Date().toISOString(),
    branch: last.branch,
    commit: last.commit,
    hash: last.hash,
    metrics: last.metrics,
    proof: crypto.createHash("sha256").update(last.hash + last.timestamp).digest("hex")
  };
  fs.writeFileSync(HIGHMARK_PATH, JSON.stringify(highmark, null, 2));
  console.log("✅ Highmark created:", highmark);
}

function compare(){
  if (!fs.existsSync(HIGHMARK_PATH)) { console.log("ℹ️ No highmark.json; creating."); create(); return; }
  const highmark = JSON.parse(fs.readFileSync(HIGHMARK_PATH, "utf8"));
  const last = loadLedger().at(-1);
  const d = {
    ratio: ((last.metrics.ratio - highmark.metrics.ratio) / highmark.metrics.ratio) * 100,
    comp: ((last.metrics.compTime - highmark.metrics.compTime) / highmark.metrics.compTime) * 100,
    dec: ((last.metrics.decTime - highmark.metrics.decTime) / highmark.metrics.decTime) * 100
  };
  console.log("📈 Delta vs Highmark (%)", d);
}

function raise(){
  if (!fs.existsSync(HIGHMARK_PATH)) { create(); return; }
  const highmark = JSON.parse(fs.readFileSync(HIGHMARK_PATH, "utf8"));
  const ledger = loadLedger();
  const last = ledger.at(-1);
  const improved = (last.metrics.ratio > highmark.metrics.ratio * 1.05)
                || (last.metrics.compTime < highmark.metrics.compTime * 0.90)
                || (last.metrics.decTime < highmark.metrics.decTime * 0.90);
  if (improved) {
    console.log("⬆️ Raising the Highmark!");
    const updated = {
      timestamp: new Date().toISOString(),
      branch: last.branch,
      commit: last.commit,
      hash: last.hash,
      metrics: last.metrics,
      proof: crypto.createHash("sha256").update(last.hash).digest("hex")
    };
    fs.writeFileSync(HIGHMARK_PATH, JSON.stringify(updated, null, 2));
    console.log("✅ New Highmark:", updated);
  } else {
    console.log("🔹 No raise — current run within baseline.");
  }
}

if (import.meta.url === `file://${process.argv[1]}`){
  const cmd = process.argv[2];
  if (cmd === "create") create();
  else if (cmd === "compare") compare();
  else if (cmd === "raise") raise();
  else console.log("Usage: node tools/highmark.js [create|compare|raise]");
}
