
// tools/relay-run.js
import { execSync } from "child_process";
import crypto from "crypto";
import fs from "fs";

export function relayTest(cmd){
  console.log("🔁 Relay check:", cmd);
  const before = execSync(cmd).toString();
  const after = execSync(cmd).toString();
  const h1 = crypto.createHash("sha256").update(before).digest("hex");
  const h2 = crypto.createHash("sha256").update(after).digest("hex");
  if (h1 !== h2) throw new Error("❌ Relay mismatch: non-deterministic output");
  fs.writeFileSync("relay-proof.json", JSON.stringify({ cmd, hash:h1 }, null, 2));
  console.log("✅ Relay proof recorded.");
}

if (import.meta.url === `file://${process.argv[1]}`){
  const cmd = process.argv.slice(2).join(" ");
  relayTest(cmd);
}
