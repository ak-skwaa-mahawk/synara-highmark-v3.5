
// tools/orion-align.js
import fs from "fs";

export function orionAlign(branchFile, mainFile, tolerance = 0.3){
  const branch = typeof branchFile === "string" ? JSON.parse(fs.readFileSync(branchFile, "utf8")) : branchFile;
  const main = typeof mainFile === "string" ? JSON.parse(fs.readFileSync(mainFile, "utf8")) : mainFile;
  const delta = Math.abs(branch.ratio - main.metrics.ratio) / Math.max(1e-9, main.metrics.ratio);
  const aligned = delta <= tolerance;
  console.log(aligned ? "🪐 Orion aligned." : `⚠️ Resonance drift: ${(delta*100).toFixed(2)}% > ${(tolerance*100).toFixed(0)}%`);
  return aligned;
}

if (import.meta.url === `file://${process.argv[1]}`){
  const [, , branchFile, mainFile] = process.argv;
  process.exit(orionAlign(branchFile, mainFile) ? 0 : 1);
}
