
// tools/fact-ledger.js
import fs from "fs";
import path from "path";
import crypto from "crypto";

const LEDGER_PATH = path.resolve("./fact-ledger.jsonl");
const PERF_SUMMARY = path.resolve("./tests/perf-summary.json");

function canon(obj) {
  const keys = Object.keys(obj).sort();
  const ordered = {};
  for (const k of keys) ordered[k] = obj[k];
  return JSON.stringify(ordered);
}
function sha256(s){ return crypto.createHash("sha256").update(s).digest("hex"); }

function readLast(){
  if (!fs.existsSync(LEDGER_PATH)) return null;
  const raw = fs.readFileSync(LEDGER_PATH, "utf8").trim();
  if (!raw) return null;
  return JSON.parse(raw.split("\n").filter(Boolean).pop());
}

export function append(){
  if (!fs.existsSync(PERF_SUMMARY)) {
    console.error("❌ Missing perf summary:", PERF_SUMMARY);
    process.exit(1);
  }
  const perf = JSON.parse(fs.readFileSync(PERF_SUMMARY, "utf8"));
  const last = readLast();

  const core = {
    index: last ? last.index + 1 : 0,
    timestamp: new Date().toISOString(),
    branch: process.env.GITHUB_REF_NAME || "local",
    commit: process.env.GITHUB_SHA || "local",
    metrics: {
      ratio: Number(perf.ratio),
      compTime: Number(perf.compTime),
      decTime: Number(perf.decTime),
      threshold: Number(perf.threshold || 0.3),
      status: perf.status || "UNKNOWN"
    },
    prev: last ? last.hash : "genesis"
  };

  const hash = sha256(canon({
    index: core.index,
    timestamp: core.timestamp,
    branch: core.branch,
    commit: core.commit,
    metrics: core.metrics,
    prev: core.prev
  }));

  const entry = { ...core, hash };
  fs.appendFileSync(LEDGER_PATH, JSON.stringify(entry) + "\n");
  console.log("✅ Ledger entry appended:", entry);
}

export function verify(){
  if (!fs.existsSync(LEDGER_PATH)) {
    console.log("ℹ️ No ledger found (nothing to verify).");
    process.exit(0);
  }
  const lines = fs.readFileSync(LEDGER_PATH, "utf8").trim().split("\n").filter(Boolean);
  let prev = "genesis";
  for (let i = 0; i < lines.length; i++) {
    const e = JSON.parse(lines[i]);
    if (e.prev !== prev) { console.error(`❌ Prev link mismatch at ${i}`); process.exit(2); }
    const calc = sha256(canon({
      index: e.index, timestamp: e.timestamp, branch: e.branch, commit: e.commit, metrics: e.metrics, prev: e.prev
    }));
    if (calc !== e.hash) { console.error(`❌ Hash mismatch at ${i}`); process.exit(2); }
    prev = e.hash;
  }
  console.log(`✅ Ledger verified (${lines.length} entries)`);
}

if (import.meta.url === `file://${process.argv[1]}`){
  const cmd = process.argv[2];
  if (cmd === "append") append();
  else if (cmd === "verify") verify();
  else console.log("Usage: node tools/fact-ledger.js [append|verify]");
}
