
// tools/ledger-benchmark-badge.js
import fs from "fs";
import path from "path";
import crypto from "crypto";

const LEDGER_PATH = path.resolve("./fact-ledger.jsonl");
const README_PATH = path.resolve("./README.md");
const avg = a => a.length ? a.reduce((x,y)=>x+y,0)/a.length : 0;

function verify(entries){
  let prev="genesis";
  for(const e of entries){
    const calc = crypto.createHash("sha256").update(JSON.stringify({index:e.index,timestamp:e.timestamp,branch:e.branch,commit:e.commit,metrics:e.metrics,prev:e.prev})).digest("hex");
    if (calc!==e.hash || e.prev!==prev) return false;
    prev = e.hash;
  }
  return true;
}

if (!fs.existsSync(LEDGER_PATH)) process.exit(0);
const lines = fs.readFileSync(LEDGER_PATH,"utf8").trim().split("\n").filter(Boolean);
const entries = lines.map(l=>JSON.parse(l));
const ok = verify(entries);
const recent = entries.slice(-10).map(e=>e.metrics);
const r = avg(recent.map(m=>m.ratio));
const c = Math.round(avg(recent.map(m=>m.compTime)));
const color = ok ? "brightgreen" : "red";
const badge = `![Benchmark ${ok ? "Verified" : "Broken"}](https://img.shields.io/badge/benchmark-${r.toFixed(3)}_ratio_${c}ms_comp-${color}?style=flat-square)`;
const md = fs.readFileSync(README_PATH,"utf8");
const updated = md.replace(/!\[Benchmark.*?\)\]/, badge).replace(/!\[Highmark.*?\)\]/, badge);
fs.writeFileSync(README_PATH, updated);
console.log(`Updated badge -> ratio ${r.toFixed(3)}, comp ${c}ms`);
