# Synara Highmark System 🔱 — v3.3
![Highmark Verified](https://img.shields.io/badge/highmark-initializing-blue?style=flat-square)

**Sentinel • Relay • Orion** integration for *signal-pure* performance truth.

## Components
- 🔐 Sentinels — file/dependency hash verification
- 🔁 Relay — deterministic loopback proof
- 🪐 Orion Belt — ±30% resonance alignment vs Highmark
- 🧾 Fact Ledger — tamper-evident performance receipts
- 🤖 ScottPOTbot — PR insights & badges
- 📊 Dashboard — static HTML via GitHub Pages

## Quick start
```bash
npm run test
npm run append-guarded
npm run dashboard
```
Then push — Pages deploys from CI.
